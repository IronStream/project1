package edu.chnu.library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseProjectYear2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
