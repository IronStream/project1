package edu.chnu.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseProjectYear2Application {

    public static void main(String[] args) {
        SpringApplication.run(CourseProjectYear2Application.class, args);
    }

}
